exports.handler = async () => ({
  statusCode: 200,
  body: 'Placeholder Lambda. Real code is deployed by the pipeline.',
});
